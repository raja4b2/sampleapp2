# Overview

This is a monorepo for the ProofPilot application frontends. It is managed by Yarn PnP and contains the following Yarn workspaces:

1. sponsor - standalone app for sponsors
2. site - standalone app for sites
3. patient - standalone app for patients
4. core - app-agnostic code including design system components along with generic hooks and utilities.

## First-time setup

### Install NVM (Node Version Manager)

1. https://github.com/nvm-sh/nvm#install--update-script
2. `nvm install 18.14.0`
3. `nvm alias default 18.14.0`

### Configure Node to use Yarn V3

```
corepack enable
```

### Install Dependencies

```
cd frontend
yarn install
```

### Configure Your IDE

If you use VS Code, when you load the frontend repo you will get prompted to install a set of plugins to enhance the developer experience. Please install them.

## Local Development

Run the apps in development mode on a local web server. The page will reload automatically when you make edits.

1. `yarn workspace sponsor dev` http://localhost:3100/sponsor
1. `yarn workspace site dev` http://localhost:4100/site
1. `yarn workspace patient dev` http://localhost:5100/patient

By default, local frontend apps connect to the hosted dev API/database (no local setup needed). If you need to develop against a local API/database:

1. Update the `config/environment.json` files to set `"engineApiUrl": "http://localhost:8080/api/v1/flightplanner"`
1. Run a local instance of the engine API/database via Docker. Docker Desktop must be installed, then clone the [engine](https://github.com/ProofPilot/engine) repo as a sibling directory to this repo. Then run:

`yarn api`

Run a local mock server to mimic talking to an API backend.

1. `yarn workspace sponsor api:mock`
1. `yarn workspace site api:mock`
1. `yarn workspace patient api:mock`

Open [http://localhost:4400/themes](http://localhost:4400/themes) to view the API response in the browser. `POST` calls can also be made to mutate the theme data.

Create a production build (minified bundles and assets), written to the /dist directory.

1. `yarn build` (all apps)
1. `yarn workspace sponsor build`
1. `yarn workspace site build`
1. `yarn workspace patient build`

Check formatting and fix any auto-fixable errors.

1. `yarn format` (all files in the entire repo)
1. `yarn workspace sponsor format`
1. `yarn workspace site format`
1. `yarn workspace patient format`

Check linting and fix any auto-fixable errors.

1. `yarn lint` (all files in the entire repo)
1. `yarn workspace sponsor lint`
1. `yarn workspace site lint`
1. `yarn workspace patient lint`
