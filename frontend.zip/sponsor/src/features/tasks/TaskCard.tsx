import { Task, OwnerTypeLabels } from './taskModel';
import clsx from 'clsx';

interface TaskCardProps {
  className?: string;
  task: Task;
}

export const TaskCard = ({ className, task }: TaskCardProps) => {
  return (
    <div
      className={clsx(
        className,
        'transition hover:scale-105 px-4 py-3 mb-4 w-72 group block max-w-xs mx-auto rounded-lg border-l-4 shadow-lg space-y-3',
        {
          'border border-theme-success': task.ownerType === 'patient',
          'border border-theme-info': task.ownerType === 'coordinator',
          'border border-theme-warning': task.ownerType === 'investigator',
        }
      )}
    >
      <div className='flex items-center space-x-3'>
        <h3 className='text-sm font-500'>{task.name}</h3>
      </div>
      {task.description && <p className='text-sm'>{task.description}</p>}
      <div
        className={clsx(
          'mt-3 px-2 py-1 rounded text-theme-base text-xs inline-block',
          {
            'bg-theme-success text-theme-inverted':
              task.ownerType === 'patient',
            'bg-theme-info text-theme-inverted':
              task.ownerType === 'coordinator',
            'bg-theme-warning text-theme-inverted':
              task.ownerType === 'investigator',
          }
        )}
      >
        {OwnerTypeLabels[task.ownerType]}
      </div>
    </div>
  );
};
