import { useState } from 'react';
import { TextInput } from 'core/components/TextInput';
import { Select } from 'core/components/Select';
import { RightBar } from 'core/components/RightBar';
import { ButtonPrimary } from 'core/components/ButtonPrimary';
import { ButtonSecondary } from 'core/components/ButtonSecondary';
import { Task, OwnerType, OwnerTypeLabels } from './taskModel';

interface EditTaskRightBarProps {
  isOpen: boolean;
  onClose(): void;
  onSave(taskToAdd: Task): void;
}

const defaultName = '';
const defaultOwnerType = 'coordinator';

export const EditTaskRightBar = ({
  isOpen = false,
  onClose,
  onSave,
}: EditTaskRightBarProps) => {
  const [name, setName] = useState(defaultName);
  const [ownerType, setOwnerType] = useState<OwnerType>(defaultOwnerType);
  const errorMessage = name ? '' : 'A value is required';

  const resetForm = () => {
    setName(defaultName);
    setOwnerType(defaultOwnerType);
  };

  const handleClose = () => {
    onClose();
    resetForm();
  };

  const handleSave = () => {
    onSave({
      name,
      ownerType,
    });
    resetForm();
  };

  return (
    <RightBar
      footer={
        <>
          <ButtonSecondary
            className='mr-1'
            label='Cancel'
            onClick={handleClose}
          />
          <ButtonPrimary
            className='ml-4'
            isDisabled={Boolean(errorMessage)}
            label='Save'
            onClick={handleSave}
          />
        </>
      }
      isOpen={isOpen}
      onClose={handleClose}
      title='Add Task'
    >
      <TextInput
        containerProps={{ className: 'mb-4' }}
        errorMessage={errorMessage}
        label='Task Name'
        onChange={setName}
        value={name}
      />
      <Select
        label='Owner'
        onChange={(newOwnerType: OwnerType) => {
          setOwnerType(newOwnerType);
        }}
        value={ownerType}
        options={Object.entries(OwnerTypeLabels).map(([key, value]) => ({
          label: value,
          value: key,
        }))}
      />
    </RightBar>
  );
};
