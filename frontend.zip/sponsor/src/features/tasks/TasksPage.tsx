import { useState } from 'react';
import { EditTaskRightBar } from './EditTaskRightBar';
import { Task } from './taskModel';
import { TaskCard } from './TaskCard';

export const TasksPage = () => {
  const [isEditTaskRightBarOpen, setIsEditTaskRightBarOpen] = useState(false);
  const [tasks, setTasks] = useState<Task[]>([
    {
      name: 'My first task',
      ownerType: 'patient',
    },
  ]);

  return (
    <>
      <h1 className='text-center font-500 mb-4 text-lg'>Tasks</h1>
      <div className='flex flex-col items-center'>
        {tasks.map((task, index) => (
          <TaskCard key={index} task={task} />
        ))}

        <button onClick={() => setIsEditTaskRightBarOpen(true)}>
          + Add Task
        </button>
        <EditTaskRightBar
          isOpen={isEditTaskRightBarOpen}
          onClose={() => setIsEditTaskRightBarOpen(false)}
          onSave={(taskToAdd: Task) => {
            setTasks((prevTasks) => [...prevTasks, taskToAdd]);
            setIsEditTaskRightBarOpen(false);
          }}
        />
      </div>
    </>
  );
};
