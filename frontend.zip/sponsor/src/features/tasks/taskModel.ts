export const OwnerTypeLabels = {
  coordinator: 'Clinical Research Coordinator',
  patient: 'Patient',
  investigator: 'Principal Investigator',
};

export type OwnerType = keyof typeof OwnerTypeLabels;

export interface Task {
  description?: string;
  name: string;
  ownerType: OwnerType;
}
