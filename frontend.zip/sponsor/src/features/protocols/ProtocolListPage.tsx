import { Link } from 'react-router-dom';
import { ButtonPrimary } from 'core/components/ButtonPrimary';
import { Icon } from 'core/components/Icon';
import { roundToDecimalPlaces } from 'core/utils/number';
import { useGetAllProtocolsQuery } from '../../services/engineApiProtocolSlice';
import { StatusLabel } from 'core/components/StatusLabel';

const DAYS_IN_WEEK = 7;

export const ProtocolListPage = () => {
  const { data: protocols } = useGetAllProtocolsQuery();

  return (
    <div className='bg-gradient-to-b from-white to-sky-100 min-h-full'>
      <div className='mx-auto sm:px-6 lg:px-8'>
        {/* Header */}
        <div className='flex flex-col w-[300px] sm:w-[580px] mx-auto my-12'>
          <h1 className='text-4xl font-700 mb-6 text-center'>
            Build a Clinical Trial Protocol
          </h1>
          <p className='mb-8 text-sm'>
            Use our Protocol Builder to quickly turn your schedule of
            assessments into actionable tasks for each responsible party, add
            reminders, participant rewards, and more!
          </p>
          <ButtonPrimary className='mx-auto' label='+ Create a New Protocol' />
        </div>

        {/* Protocols List */}
        {protocols && protocols.length > 0 && (
          <div className='bg-white shadow-md px-5 pt-8 mb-12 max-w-7xl mx-auto'>
            <table className='min-w-full'>
              <thead>
                <tr className='border-theme-primary border-b-4'>
                  <th
                    scope='col'
                    className='pb-2 text-left text-xl sm:text-4xl font-700 w-full whitespace-nowrap'
                  >
                    Protocols ({protocols.length})
                  </th>
                  <th scope='col'>
                    <div className=''>
                      <Icon
                        className='mx-auto hidden sm:block'
                        size='lg'
                        type='listBullet'
                      />
                    </div>
                    <span className='sr-only'>Tasks</span>
                  </th>
                  <th scope='col'>
                    <Icon
                      className='mx-auto hidden sm:block'
                      size='lg'
                      type='clock'
                    />
                    <span className='sr-only'>Duration</span>
                  </th>
                  <th scope='col'>
                    <Icon
                      className='mx-auto hidden sm:block'
                      size='lg'
                      type='playPause'
                    />
                    <span className='sr-only'>Status</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {protocols.map((protocol) => (
                  <tr key={protocol.shortId}>
                    <td className='w-full pr-1 sm:pr-5'>
                      <Link
                        className='py-4 block group'
                        to={`/protocols/${protocol.shortId}`}
                      >
                        <div className='text-lg sm:text-2xl font-500 group-hover:text-theme-primary'>
                          {protocol.name}
                        </div>
                        {protocol.description && (
                          <p className='hidden sm:block mt-2 text-sm'>
                            {protocol.description}
                          </p>
                        )}
                      </Link>
                    </td>
                    <td className='text-right px-2 sm:px-5'>
                      <div className='text-lg sm:text-2xl leading-4 font-500 whitespace-nowrap'>
                        {protocol.activityCount}
                      </div>
                      <div className='text-sm sm:text-lg whitespace-nowrap'>
                        tasks
                      </div>
                    </td>
                    <td className='text-right px-1 sm:px-5'>
                      <div className='text-lg sm:text-2xl leading-4 font-500 whitespace-nowrap'>
                        {roundToDecimalPlaces(
                          protocol.durationDays / DAYS_IN_WEEK,
                          1,
                        )}
                      </div>
                      <div className='text-sm sm:text-lg whitespace-nowrap'>
                        weeks
                      </div>
                    </td>
                    <td className='text-center pl-2 sm:pl-5 pr-2'>
                      <StatusLabel
                        className='sm:min-w-[88px]'
                        label='Draft'
                        type='warning'
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
