import { useParams } from 'react-router-dom';
import clsx from 'clsx';
import {
  ProtocolRoles,
  useGetProtocolQuery,
} from '../../services/engineApiProtocolSlice';
import { StatusLabel } from 'core/components/StatusLabel';

const RoleColorClasses: Record<ProtocolRoles, string> = {
  clinicalResearchCoordinator: 'border-green-500',
  labTechnician: 'border-purple-500',
  patient: 'border-blue-500',
  siteInvestigator: 'border-orange-500',
};

const formatIntervalDayRange = (
  dayNumber: number,
  dayWindowBefore = 0,
  dayWindowAfter = 0
) => {
  if (dayWindowBefore === 0 && dayWindowAfter === 0) {
    return `D${dayNumber}`;
  } else if (dayWindowBefore === dayWindowAfter) {
    return `D${dayNumber}±${dayWindowBefore}`;
  } else if (dayWindowBefore) {
    return `D${dayNumber}(-${dayWindowBefore})`;
  } else {
    return `D${dayNumber}(+${dayWindowAfter})`;
  }
};

export const ProtocolDetailPage = () => {
  const { protocolId } = useParams();
  const { data: protocol } = useGetProtocolQuery(Number(protocolId));
  // other values are isLoading, isSuccess, isError, error

  if (protocol) {
    return (
      <div className='min-h-full'>
        <div className='mx-auto px-2 sm:px-6 lg:px-8'>
          {/* Header */}
          <div className='flex items-start justify-between mb-6 mt-8'>
            <div>
              <h1 className='font-500 text-3xl'>{protocol.name}</h1>
              {protocol.description && (
                <p className='mt-2 text-sm'>{protocol.description}</p>
              )}
            </div>
            <StatusLabel
              className='mt-1 ml-6 sm:min-w-[88px]'
              label='Draft'
              type='warning'
            />
          </div>

          {/* Timeline */}
          <div className='flex justify-between items-end mb-3'>
            <h2 className='font-500 text-2xl'>Timeline</h2>
            <div className='ml-6 text-right'>
              <div className='text-sm'>Study Length</div>
              <div className='text-lg'>{protocol.durationDays} days</div>
            </div>
          </div>

          {/* Stages */}
          <div className='flex gap-4 self-stretch items-stretch justify-items-stretch justify-self-stretch min-h-full h-full overflow-x-auto'>
            {protocol.stages.map((stage) => (
              <div
                key={stage.name}
                className='border border-gray-100 rounded shadow-md'
              >
                <h3 className='mb-1.5 border-b px-3 py-2 text-sm'>
                  {stage.name}
                </h3>
                {/* Intervals */}
                <h4 className='text-center font-500 text-sm'>
                  {stage.intervals.length}{' '}
                  {stage.intervals.length === 1 ? 'visit' : 'visits'}
                </h4>
                <div className='flex gap-2'>
                  {stage.intervals.map((interval) => (
                    <div key={interval.id} className='p-1'>
                      <div className='mb-2 font-500 text-sm text-center'>
                        {formatIntervalDayRange(
                          interval.dayNumber,
                          interval.dayWindowBefore,
                          interval.dayWindowAfter
                        )}
                      </div>
                      {/* Activities */}
                      <div className='bg-gray-50 p-1 w-40 h-60'>
                        {interval.activities?.map((activity) => (
                          <div
                            key={activity.id}
                            className={clsx(
                              RoleColorClasses[activity.role],
                              'border border-l-[3px] rounded shadow-sm bg-white mb-2 px-2 py-1'
                            )}
                          >
                            <div className='text-xs'>{activity.name}</div>
                            <div className='flex justify-between'>
                              {/* category icons will go here */}
                              <div />
                              <div className='text-[10px] text-gray-400'>
                                {activity.estimatedDurationMinutes} min
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  } else {
    return <div>Something went wrong</div>;
  }
};
