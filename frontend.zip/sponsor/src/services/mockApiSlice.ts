import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

interface ThemeColors {
  name: string;
  value: string;
}
interface ThemeProperties {
  name: string;
  value: ThemeColors[];
}
export interface Theme {
  id: number;
  name: string;
  properties: ThemeProperties[];
}

export const mockApiSlice = createApi({
  reducerPath: 'themes',
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_MOCK_API_URL as string,
    prepareHeaders: (headers) => {
      // TODO: auth will go here
      // headers.set('key', 'value');
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getThemes: builder.query<Theme[], void | never>({
      query: () => '/themes',
    }),
    getTheme: builder.mutation<Theme, number>({
      query: (themeId) => ({
        url: `/themes/${themeId}`,
        method: 'GET',
      }),
    }),
    setTheme: builder.mutation<Theme, Theme>({
      query: (theme) => ({
        url: `/themes/${theme.id}`,
        method: 'PUT',
        body: theme,
      }),
    }),
  }),
});

export const { useGetThemesQuery, useGetThemeMutation, useSetThemeMutation } =
  mockApiSlice;
