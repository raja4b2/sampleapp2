import { engineApiBaseSlice } from './engineApiBaseSlice';

interface ProtocolTask {
  id: number;
  name: string;
  description?: string;
}

export type ProtocolRoles =
  | 'clinicalResearchCoordinator'
  | 'labTechnician'
  | 'patient'
  | 'siteInvestigator';

interface ProtocolActivity {
  id: number;
  name: string;
  role: ProtocolRoles;
  description?: string;
  estimatedDurationMinutes?: number;
  tasks?: ProtocolTask[];
}

interface ProtocolInterval {
  id: number;
  dayNumber: number;
  dayWindowBefore?: number;
  dayWindowAfter?: number;
  activities?: ProtocolActivity[];
}

interface ProtocolStage {
  name: string;
  intervals: ProtocolInterval[];
}

interface LimitedProtocol {
  id: number;
  shortId: number;
  activityCount: number;
  durationDays: number;
  name: string;
  description?: string;
}

export interface Protocol extends LimitedProtocol {
  stages: ProtocolStage[];
}

interface ProtocolPayload {
  project: Protocol;
}

interface AllProtocolsPayload {
  projects: LimitedProtocol[];
}

const engineApiProtocolSlice = engineApiBaseSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAllProtocols: builder.query<LimitedProtocol[], void | never>({
      query: () => '/flightplanner/projects',
      transformResponse: (response: AllProtocolsPayload) => response.projects,
    }),
    getProtocol: builder.query<Protocol, number>({
      query: (protocolId) => `/flightplanner/projects/d/${protocolId}`,
      transformResponse: (response: ProtocolPayload) => response.project,
    }),
  }),
});

export const { useGetAllProtocolsQuery, useGetProtocolQuery } =
  engineApiProtocolSlice;
