module.exports = {
  extends: [
    'kentcdodds',
    'kentcdodds/import',
    'kentcdodds/jsx-a11y',
    'kentcdodds/react',
  ],
  rules: {
    /**
     * DISABLED RULES FROM KENTCDODDS PRESETS
     */
    'import/order': 'off', // too fussy
    'react/react-in-jsx-scope': 'off', // modern build tooling handles this for us
    'react/jsx-no-leaked-render': 'off', // ternary render makes code harder to read. casting as boolean breaks typescipt. so leave off for now.

    /**
     * OUR OWN ADDITIONAL RULES ON TOP OF KENTCDODDS PRESETS
     */
    'no-console': 'warn', // we want a clean console in deployed environments
    'no-implicit-coercion': 'error', // coercion is hard to read - use casting instead
    'react-hooks/exhaustive-deps': 'off', 
  },
};
