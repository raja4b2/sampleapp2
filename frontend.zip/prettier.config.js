/**
 * Any settings not declared in this file will inherit from Prettier's default settings.
 * @link https://prettier.io/docs/en/options.html
 */
module.exports = {
  jsxSingleQuote: true,
  singleQuote: true,
  trailingComma: 'all', // will become the default in v3, so can remove this once we upgrade
};
