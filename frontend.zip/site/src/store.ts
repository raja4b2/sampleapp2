import { configureStore } from '@reduxjs/toolkit';
import { engineApiBaseSlice } from './services/engineApiBaseSlice';
import { mockApiSlice } from './services/mockApiSlice';
import { environmentSlice } from './services/environmentSlice';
import { knowledgeBaseApiSlice } from './services/knowledgeBaseApiSlice';

export const store = configureStore({
  reducer: {
    [environmentSlice.name]: environmentSlice.reducer,
    [engineApiBaseSlice.reducerPath]: engineApiBaseSlice.reducer,
    [mockApiSlice.reducerPath]: mockApiSlice.reducer,
    [knowledgeBaseApiSlice.reducerPath]: knowledgeBaseApiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      engineApiBaseSlice.middleware,
      mockApiSlice.middleware,
      knowledgeBaseApiSlice.middleware,
    ),
});

// https://react-redux.js.org/using-react-redux/usage-with-typescript#define-root-state-and-dispatch-types
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
