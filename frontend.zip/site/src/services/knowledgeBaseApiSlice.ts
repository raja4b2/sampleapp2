import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { KnowledgeBaseDocument, KnowledgeBaseDocumentDetailsResponse, KnowledgeBaseDocumentListResponse, KnowledgeBaseDocumentsQueryPayLoad } from '../features/knowledge-base/KnowledgeBaseModel';

export const knowledgeBaseApiSlice = createApi({
  reducerPath: 'knowledgeBase',
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_KNOWLEDGE_BASE_API_URL as string,
    prepareHeaders: (headers) => {
      headers.set(
        'api_token',
        import.meta.env.VITE_KNOWLEDGE_BASE_TOKEN as string,
      );
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getKnowledgeBaseDocuments: builder.mutation<
    KnowledgeBaseDocumentListResponse,
    KnowledgeBaseDocumentsQueryPayLoad
    >({
      query: ({ projectId, searchTerm }) => ({
        url: `/v1/projectversions/${projectId}?searchQuery=${searchTerm}`,
        method: 'GET',
      }),
    }),
    getKnowledgeBaseDocumentDetails: builder.mutation<
    KnowledgeBaseDocumentDetailsResponse,
    KnowledgeBaseDocument
    >({
      query: (queryObj) => ({
        url: `/v1/articles/${queryObj.articleId}`,
        method: 'GET',
      }),
    }),
  }),
});

export const {
  useGetKnowledgeBaseDocumentsMutation,
  useGetKnowledgeBaseDocumentDetailsMutation,
} = knowledgeBaseApiSlice;
