import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface EnvironmentConfig {
  environmentName?: 'prod' | 'stage' | 'dev' | 'local';
  engineApiUrl?: string;
  mockApiUrl?: string;
  releaseVersion?: string;
}

const initialState: EnvironmentConfig = {
  engineApiUrl: undefined,
  environmentName: undefined,
  mockApiUrl: undefined,
  releaseVersion: undefined,
};

export const environmentSlice = createSlice({
  name: 'environment',
  initialState,
  reducers: {
    setEnvironment(_state, action: PayloadAction<EnvironmentConfig>) {
      return action.payload;
    },
  },
});

export const { setEnvironment } = environmentSlice.actions;
