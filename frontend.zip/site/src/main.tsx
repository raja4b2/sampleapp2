import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store';
import { setEnvironment, EnvironmentConfig } from './services/environmentSlice';
import { DashboardPage } from './features/dashboard/DashboardPage';
import { ChatPage } from './features/chat/ChatPage';
import { KnowledgeBasePage } from './features/knowledge-base/KnowledgeBasePage';

import { Header } from './Header';
import './main.css';

// Typically environment variables are injected at build time (for example via Vite), and
// then a distribution is built for each target environment. We have chosen to load env vars
// at runtime instead so that we can build once and share that build across all environments.
fetch('/site/config/environment.json')
  .then((response) => response.json())
  .then((environmentConfig: EnvironmentConfig) => {
    store.dispatch(setEnvironment(environmentConfig));
    ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
      <React.StrictMode>
        <Provider store={store}>
          <BrowserRouter basename='/site'>
            <div className='flex flex-col h-full text-theme-base'>
              <Header />
              <Routes>
                <Route path='/' element={<DashboardPage />} />
                <Route path='/chat' element={<ChatPage />} />
                <Route path='/knowledge-base' element={<KnowledgeBasePage />} />
              </Routes>
            </div>
          </BrowserRouter>
        </Provider>
      </React.StrictMode>,
    );
  })
  .catch((_error: ErrorEvent) => {
    // TODO: log this error
    ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
      <React.StrictMode>
        <h1>Error loading config</h1>
      </React.StrictMode>,
    );
  });
