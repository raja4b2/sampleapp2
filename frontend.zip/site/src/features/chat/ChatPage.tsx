export const ChatPage = () => {
  return <div>Chat</div>;
};
