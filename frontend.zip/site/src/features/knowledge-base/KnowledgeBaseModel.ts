export interface MatchedWordsTitle {
    title: {
      matchLevel: string;
      matchedWords: string[];
      value: string;
    };
  }
  export interface MatchedWordsContent {
    content: {
      matchLevel: string;
      value: string;
    };
  }
  export interface KnowledgeBaseDocument {
    articleId: string;
    attachmentIds: string[];
    breadcrumb: string;
    categoryId: string;
    categoryUniqueId: string;
    content: string;
    contributors: string[];
    exclude: boolean;
    isCategory: boolean;
    isCategoryHidden: boolean;
    isDeleted: boolean;
    isDraft: boolean;
    isFolderTypeCategory: boolean;
    isHidden: boolean;
    isLatestVersion: boolean;
    isPrivate: boolean;
    langCode: string;
    languageId: string;
    objectID: string;
    order: number;
    projectId: string;
    slug: string;
    tags: string[];
    title: string;
    uniqueId: string;
    updatedOnTimestamp: number;
    version: number;
    _highlightResult: MatchedWordsTitle;
    _snippetResult: MatchedWordsContent;
  }
  
  export interface KnowledgeBaseDocumentListResponse {
    data: {
      exhaustiveNbHits: boolean;
      hits: KnowledgeBaseDocument[];
      hitsPerPage: number;
      nbHits: number;
      nbPages: number;
      page: number;
      params: string;
      processingTimeMS: number;
      query: string;
    };
    errors: string[];
    extension_data: string;
    information: string[];
    success: boolean;
    warnings: string[];
  }
  export interface AuthorInfo {
    authentication_id: string;
    customer_id: string;
    email_id: string;
    first_name: string;
    fresh_chat_restore_id: string;
    id: string;
    initial_tour_shown: boolean;
    is_enterprise_user: boolean;
    is_user_existin_current_project: boolean;
    last_login_date: string;
    last_name: string;
    profile_logo_cdn_url: string;
    profile_logo_url: string;
    scheme_name: string;
    signup_date: string;
    status: number;
    unique_user_name: string;
    user_description: string;
    errors: string[];
    extension_data: string;
    information: string[];
    success: boolean;
    warnings: string[];
  }
  
  export interface KnowledgeBaseDocumentDetails {
    article_index: number;
    authors: AuthorInfo[];
    block_content: string;
    category_id: string;
    category_type: string;
    content: string;
    content_type: number;
    created_at: string;
    created_by: string;
    description: string;
    enable_rtl: boolean;
    hidden: boolean;
    html_content: string;
    id: string;
    is_fall_back_content: boolean;
    latest_version: number;
    modified_at: string;
    order: number;
    project_version_id: string;
    public_version: number;
    slug: string;
    status: number;
    title: string;
    version_number: number;
  }
  
  export interface KnowledgeBaseDocumentDetailsResponse {
    data: KnowledgeBaseDocumentDetails;
  }

  export interface KnowledgeBaseDocumentsQueryPayLoad {
    projectId: string;
    searchTerm: string;
  }