import React, { useEffect, useState } from 'react';
import {
  useGetKnowledgeBaseDocumentDetailsMutation,
  useGetKnowledgeBaseDocumentsMutation,
} from '../../services/knowledgeBaseApiSlice';
import { Icon } from 'core/components/Icon';
import './KnowledgeBase.css';
import {
  KnowledgeBaseDocument,
  KnowledgeBaseDocumentDetails,
  KnowledgeBaseDocumentDetailsResponse,
  KnowledgeBaseDocumentListResponse,
} from './KnowledgeBaseModel';
import clsx from 'clsx';

export const KnowledgeBasePage = () => {
  const [documentDetails, setDocumentDetails] =
    useState<KnowledgeBaseDocumentDetails>();
  const [search, setSearch] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [documentsList, setDocumentsList] = useState([]);
  const [isMobileView, setIsMobileView] = useState(false);
  const [isSuggestionMenu, setIsSuggestionMenu] = useState(false);
  const [studyTitle, setStudyTitle] = useState('');
  const [getKnowledgeBaseDocuments] = useGetKnowledgeBaseDocumentsMutation();
  const [getKnowledgeBaseDocumentDetails] =
    useGetKnowledgeBaseDocumentDetailsMutation();

  const searchKnowledgeBaseContentByArticleId = (
    document: KnowledgeBaseDocument,
  ) => {
    getKnowledgeBaseDocumentDetails(document)
      .unwrap()
      .then((res: KnowledgeBaseDocumentDetailsResponse) => {
        setDocumentDetails(res.data);
      })
      .catch(() => {});
  };

  const selectDocument = (item: KnowledgeBaseDocument) => {
    setIsMobileView(true);
    setDocumentDetails();
    setIsSuggestionMenu(false);
    searchKnowledgeBaseContentByArticleId(item);
  };

  const getKnowledgeBaseDocumentsAPI = (
    searchTerm: string,
    isLoadingFirstTime: boolean,
  ) => {
    getKnowledgeBaseDocuments({
      projectId: 'fdfe4bf5-4ed7-4122-b233-f9a4ca544874',
      searchTerm,
    })
      .unwrap()
      .then((res: KnowledgeBaseDocumentListResponse) => {
        setSuggestions(res.data.hits);
        if (isLoadingFirstTime) {
          setDocumentsList(res.data.hits);
          selectDocument(res.data.hits[0]);
        }
      })
      .catch(() => {});
  };
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setIsSuggestionMenu(true);
    getKnowledgeBaseDocumentsAPI(e.target.value, false);
  };

  const goToDocumentsList = () => {
    setIsMobileView(false);
  };

  useEffect(() => {
    getKnowledgeBaseDocumentsAPI('', true);

    // Need to implement the API once Auth token and backend API's are ready
    setStudyTitle('Sample study');
  }, []);

  useEffect(() => {
    document.addEventListener('click', () => {
      setIsSuggestionMenu(false);
    });
    return () => {
      document.removeEventListener('click', () => {
        setIsSuggestionMenu(false);
      });
    };
  }, []);
  return (
    <div className='md:grid md:grid-cols-4'>
      <div
        className={clsx('bg-[#002539] text-white h-max', {
          'hidden md:block': Boolean(isMobileView),
        })}
      >
        <div className='px-6 pb-2.5 pt-6'>
          <div className='mt-1.5 text-base'>Documents for {studyTitle}</div>
          <div className='relative'>
            <input
              type='text'
              className='shadow appearance-none border rounded w-full py-2 px-3 mt-1.5 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'
              placeholder='Search All Documents...'
              value={search}
              onChange={handleSearch}
            />
            <span className='icon-search doc-search-icon' />
            {isSuggestionMenu && (
              <div className='absolute bg-white mt-0.5 rounded max-h-96 overflow-auto z-[100] text-[#484E57] max-w-full md:max-w-screen-md'>
                {suggestions.map((item: KnowledgeBaseDocument) => (
                  <div
                    className='border border-solid border-lightgray-600 px-2.5 py-3.5'
                    key={item.articleId}
                    onClick={() => selectDocument(item)}
                    aria-hidden='true'
                  >
                    <div className='text-lg font-bold'>{item.title}</div>
                    <div className='mt-1.5 truncate text-sm text-[#626262]'>
                      {item.content}
                    </div>
                    <div className='mt-1.5'>
                      {item.breadcrumb} &gt; {item.slug}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        <div className='px-2.5'>
          {documentsList.map((item: KnowledgeBaseDocument) => (
            <div
              className={`py-6 px-5 flex text-base items-center border-b-2 border-[#00BFF2] ${
                item.articleId === documentDetails?.id ? 'bg-[#00BFF2]' : ''
              }`}
              key={item.articleId}
              onClick={() => selectDocument(item)}
              aria-hidden='true'
            >
              <span className='w-14 h-14 flex items-center'>
                <Icon
                  className='inline text-white mr-4'
                  type='documentText'
                  size='lg'
                />
              </span>
              <span>{item.title}</span>
            </div>
          ))}
        </div>
      </div>

      <div
        className={`col-span-3 p-6 md:bg-gray-200 ${
          isMobileView ? '' : 'hidden md:block'
        }`}
      >
        {documentDetails?.id && (
          <div>
            <div className='flex items-center text-white bg-theme-primary text-base py-6 px-5 md:hidden'>
              <span onClick={goToDocumentsList} aria-hidden='true'>
                <Icon className='text-white' type='chevronLeft' size='lg' />
              </span>
              <span className='mr-1'>
                <Icon className='text-white' type='documentText' size='lg' />
              </span>
              <span>{documentDetails.title}</span>
            </div>
            <div className='KnowledgeBaseDocumentDetails bg-white p-6 md:p-16'>
              <h1 className='hidden md:block'>{documentDetails.title}</h1>
              <p className='text-gray-400'>
                Updated on:{' '}
                {new Date(documentDetails.modified_at).toDateString()}
              </p>
              <div
                dangerouslySetInnerHTML={{
                  __html: documentDetails.html_content,
                }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
