import baseConfig from '../.lintstagedrc.mjs';

// https://github.com/okonet/lint-staged#how-to-use-lint-staged-in-a-multi-package-monorepo
export default {
  ...baseConfig,
};
