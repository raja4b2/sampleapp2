import { configureStore } from '@reduxjs/toolkit';
import { autoPilotApiBaseSlice } from './services/autoPilotApiBaseSlice';
import { mockApiSlice } from './services/mockApiSlice';
import { environmentSlice } from './services/environmentSlice';

export const store = configureStore({
  reducer: {
    [environmentSlice.name]: environmentSlice.reducer,
    [autoPilotApiBaseSlice.reducerPath]: autoPilotApiBaseSlice.reducer,
    [mockApiSlice.reducerPath]: mockApiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(
      autoPilotApiBaseSlice.middleware,
      mockApiSlice.middleware,
    ),
});

// https://react-redux.js.org/using-react-redux/usage-with-typescript#define-root-state-and-dispatch-types
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
