import { useEffect, useCallback } from 'react';
import { Dropdown } from 'core/components/Dropdown';
import {
  Theme,
  useGetThemeMutation,
  useGetThemesQuery,
} from '../../services/mockApiSlice';

export const ThemeSelector = () => {
  const [getTheme] = useGetThemeMutation();
  const { data: themes, isSuccess } = useGetThemesQuery();
  let themeDropdown;

  const getSelectedTheme = useCallback(
    (themeId: number) => {
      getTheme(themeId)
        .unwrap()
        .then((theme: Theme) => {
          const root = document.documentElement;
          theme.properties.forEach((prop) => {
            prop.value.forEach((color) => {
              root.style.setProperty(
                `--color-${prop.name}-${color.name}`,
                color.value
              );
            });
          });
        })
        .catch((error: string) => {
          throw new Error(error);
        });
    },
    [getTheme]
  );

  if (isSuccess) {
    const themeLis = themes.map((theme) => {
      return {
        id: theme.id,
        text: theme.name,
      };
    });
    themeDropdown = (
      <Dropdown
        variant='secondary'
        label='Themes'
        options={themeLis}
        onChange={(selectedTheme) => {
          getSelectedTheme(selectedTheme.id);
        }}
      />
    );
  }

  useEffect(() => {
    getSelectedTheme(1);
  }, [getSelectedTheme]);

  return (
    <div className='flex-grow '>
      <nav className='flex flex-grow'>{themeDropdown}</nav>
    </div>
  );
};
