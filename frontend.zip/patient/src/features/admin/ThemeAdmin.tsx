import clsx from 'clsx';
import { useCallback, useEffect, useState } from 'react';
import { ButtonPrimary } from 'core/components/ButtonPrimary';
import { ButtonSecondary } from 'core/components/ButtonSecondary';
import {
  Theme,
  useGetThemesQuery,
  useGetThemeMutation,
  useSetThemeMutation,
} from '../../services/mockApiSlice';

const propNameMap = new Map<string, string>([
  ['bg', 'Background'],
  ['text', 'Text'],
  ['border', 'Border'],
  ['ring', 'Outline'],
]);

export const ThemeAdmin = () => {
  const [isLive, setIsLive] = useState(false);
  const [clientTheme, setClientTheme] = useState<Theme>({
    id: 0,
    name: '-',
    properties: [],
  });

  const { data: themes } = useGetThemesQuery();
  // other values are isLoading, isSuccess, isError, error

  const [getTheme] = useGetThemeMutation();
  const [setTheme, { isLoading }] = useSetThemeMutation();

  const setSelectedTheme = useCallback(
    (themeId: number) => {
      getTheme(themeId)
        .unwrap()
        .then((theme: Theme) => {
          setClientTheme(theme);
        })
        .catch((error: string) => {
          throw new Error(error);
        });
    },
    [getTheme]
  );

  useEffect(() => {
    setSelectedTheme(1);
  }, [setSelectedTheme]);

  const saveTheme = () => {
    setTheme(clientTheme).catch((error: string) => {
      throw new Error(error);
    });
  };

  // Temp kept utils here, until we finalize
  const rgbToHex = (rgb: string) => {
    return rgb
      .split(',')
      .map((val) => val.trim())
      .reduce((hex, rgbVal) => {
        const hexVal = Number(rgbVal).toString(16);
        return hex + (hexVal.length === 1 ? `0${hexVal}` : hexVal);
      }, '#');
  };

  const hexToRgb = (hex: string) => {
    if (hex.length !== 6) {
      throw new Error('Only six-digit hex colors are allowed.');
    }

    const aRgbHex = hex.match(/.{1,2}/g);
    let aRgb = [0, 0, 0];
    if (aRgbHex) {
      aRgb = [
        parseInt(aRgbHex[0], 16),
        parseInt(aRgbHex[1], 16),
        parseInt(aRgbHex[2], 16),
      ];
    }
    return aRgb.join(',');
  };

  const setColor = (propName: string, name: string, value: string) => {
    const root = document.documentElement;
    const rgbColor = hexToRgb(value.replace('#', ''));
    setClientTheme((preState) => {
      if (isLive) {
        root.style.setProperty(`--color-${propName}-${name}`, rgbColor);
      }

      const properties = preState.properties.map((prop) => {
        const property = { ...prop };
        if (prop.name === propName) {
          property.value = property.value.map((clr) => {
            const color = { ...clr };
            if (color.name === name) {
              color.value = rgbColor;
            }
            return color;
          });
        }
        return property;
      });

      return { ...preState, properties: [...properties] };
    });
  };

  return (
    <>
      <div className='flex items-center'>
        <div className='mr-6'>Themes: </div>
        <nav className='flex flex-grow'>
          <ul className='flex flex-grow justify-start flex-wrap items-center gap-4'>
            {themes?.map((theme) => {
              return (
                <li key={theme.id}>
                  <button
                    onClick={() => {
                      setSelectedTheme(theme.id);
                    }}
                    className={clsx('border font-700 py-2 px-4 rounded', {
                      'bg-white hover:bg-gray-50 text-gray-500':
                        theme.name === 'Winter',
                      'bg-slate-500 hover:bg-slate-700 text-white':
                        theme.name === 'Halloween',
                    })}
                  >
                    {theme.name}
                  </button>
                </li>
              );
            })}
            <li>
              <div className='flex items-center'>
                <input
                  id='live-update'
                  type='checkbox'
                  checked={isLive}
                  onChange={() => {
                    setIsLive(!isLive);
                  }}
                  className='cursor-pointer w-4 h-4 text-theme-base bg-theme-base border-theme-secondary rounded focus:ring-0'
                />
                <label
                  htmlFor='live-update'
                  className='cursor-pointer ml-2 text-sm font-medium text-theme-base dark:text-gray-300'
                >
                  Need live update?
                </label>
              </div>
            </li>
          </ul>
          <ul className='flex flex-grow justify-end flex-wrap items-center gap-4'>
            <li>
              <button
                onClick={saveTheme}
                className='border font-700 py-2 px-4 rounded bg-white hover:bg-gray-50 text-gray-500'
              >
                {isLoading ? 'Saving' : 'Save'}
              </button>
            </li>
          </ul>
        </nav>
      </div>
      <div className='mt-4 flex gap-4 text-xl text-center font-700 relative p-2  items-center leading-6 transition'>
        <ButtonPrimary label='Primary' />
        <ButtonSecondary label='Secondary' />
        <button className='bg-theme-success text-theme-inverted border-theme-success focus:ring-theme-success capitalize inline-flex rounded border bg-opacity-90 items-center   px-4 py-2 text-sm font-medium shadow-sm hover:bg-opacity-100  focus:ring-2 focus:ring-offset-2'>
          Success
        </button>
        <button className='bg-theme-info text-theme-inverted border-theme-info focus:ring-theme-info capitalize inline-flex rounded border bg-opacity-90 items-center   px-4 py-2 text-sm font-medium shadow-sm hover:bg-opacity-100  focus:ring-2 focus:ring-offset-2'>
          Info
        </button>
        <button className='bg-theme-warning text-theme-inverted border-theme-warning focus:ring-theme-warning capitalize inline-flex rounded border bg-opacity-90 items-center   px-4 py-2 text-sm font-medium shadow-sm hover:bg-opacity-100  focus:ring-2 focus:ring-offset-2'>
          Warning
        </button>
        <button className='bg-theme-error text-theme-inverted border-theme-error focus:ring-theme-error capitalize inline-flex rounded border bg-opacity-90 items-center   px-4 py-2 text-sm font-medium shadow-sm hover:bg-opacity-100  focus:ring-2 focus:ring-offset-2'>
          Error
        </button>

        <span className='text-sm text-theme-success'>Success Text</span>
        {/* <span className='text-sm bg-theme-success text-theme-inverted rounded px-3 py-0.5'>
          Success
        </span> */}
        <span className='text-sm text-theme-error'>Error Text</span>
        {/* <span className='text-sm bg-theme-error text-theme-inverted rounded px-3 py-0.5'>
          Error
        </span> */}
      </div>
      <div className='text-xl text-center font-700 relative p-2 leading-6 transition'>
        {clientTheme.name}
      </div>
      <div className='mt-4'>
        <div className='mb-4 mx-auto'>
          <div className='grid grid-cols-12 gap-4'>
            {clientTheme.properties.map((prop, index) => {
              return (
                <div
                  key={index}
                  className='col-span-12 sm:col-span-6 lg:col-span-3'
                >
                  <div className='rounded-sm p-6 leading-6 transition shadow-[0_1px_3px_rgba(15,23,42,0.03),0_1px_2px_rgba(15,23,42,0.06)] ring-1 ring-theme-base/[0.2]'>
                    <div className='capitalize text-center pb-1 mb-3 border-b border-theme-muted font-500'>
                      {propNameMap.get(prop.name)}
                    </div>
                    <div className='text-sm'>
                      {prop.value.map((color, clrIndex) => {
                        const hexVal = rgbToHex(color.value);
                        return (
                          <div
                            key={clrIndex}
                            className='flex items-center mb-5'
                          >
                            <div className='flex items-center'>
                              <label className='inline-block w-20 mr-6 text-right capitalize'>
                                {color.name}
                              </label>
                              <input
                                className='cursor-pointer rounded border-none appearance-none bg-transparent h-8 w-8'
                                name={color.name}
                                type='color'
                                onChange={(event) => {
                                  setColor(
                                    prop.name,
                                    color.name,
                                    event.target.value
                                  );
                                }}
                                value={hexVal}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};
