import chartPlaceholder from '../../assets/chartPlaceholder.png';

export const DashboardPage = () => {
  return (
    <div className='mx-auto mt-16 text-center'>
      <img className='w-80 opacity-40' src={chartPlaceholder} alt='' />
      <h1>PATIENT APP</h1>
    </div>
  );
};
