import { Task } from './taskModel';
import { Card } from 'core/components/Card';
import infoTask from '../../assets/infoTask.png';
import scheduleTask from '../../assets/scheduleTask.png';
import surveyTask from '../../assets/surveyTask.png';
import taskPlaceholder from '../../assets/taskPlaceholder.png';

interface TaskCardProps {
  className?: string;
  task: Task;
}

export const TaskCard = ({ className, task }: TaskCardProps) => {
  const getTaskLogo = (type: Task['type']) => {
    switch (type) {
      case 'survey':
        return surveyTask;
      case 'info':
        return infoTask;
      case 'schedule':
        return scheduleTask;
      default:
        return taskPlaceholder;
    }
  };
  return (
    <Card isHoverable={true} className={className}>
      <div className='flex'>
        <div className='flex-shrink-0 flex items-center'>
          <img className='h-20 w-20' src={getTaskLogo(task.type)} alt='' />
        </div>
        <div className='min-w-0 flex-1'>
          <div className='px-4 py-3 sm:px-6'>
            <div>
              <p className='mt-2 flex items-center text-sm sm:mt-0'>
                Due
                <time className='ml-1' dateTime={task.dateDue}>
                  {new Date(task.dateDue).toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </time>
              </p>
            </div>
            <div className='flex items-center justify-between mt-2'>
              <p className='text-base font-medium'>{task.name}</p>
            </div>
            <div>
              <div>
                <p className='mt-2 flex text-gray-500 items-center text-sm sm:mt-0'>
                  {task.description}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};
