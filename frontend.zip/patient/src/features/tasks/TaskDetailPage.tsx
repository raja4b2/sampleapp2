import { useParams } from 'react-router-dom';
import { InfoTask } from './info-task/InfoTask';
import { SurveyTask } from './survey-task/SurveyTask';
import { ScheduleTask } from './schedule-task/ScheduleTask';
import { useGetTaskQuery } from '../../services/autoPilotApiTasksSlice';
import {
  InfoTaskPayload,
  ScheduleTaskPayload,
  SurveyTaskPayload,
} from './taskModel';

export const TaskDetailPage = () => {
  const { taskId } = useParams();
  const { data: task, isSuccess } = useGetTaskQuery(taskId ?? '');

  const getTaskComponent = () => {
    switch (task?.type) {
      case 'info':
        // TODO: convert to type guards?
        return (
          <InfoTask taskId={task.id} data={task.payload as InfoTaskPayload} />
        );
      case 'schedule':
        return <ScheduleTask data={task.payload as ScheduleTaskPayload} />;
      case 'survey':
        return <SurveyTask data={task.payload as SurveyTaskPayload} />;
      default:
        return <div>Oops! Something is wrong with this task.</div>;
    }
  };

  return (
    <div className='container mx-auto mt-16 px-4 max-w-2xl'>
      {/* Added condition to render when task is available
       * Because on first load, for a sec, it shows "Oops! Something is wrong..." before it loads actual task
       * TO-DO handle error
       */}
      {isSuccess && getTaskComponent()}
    </div>
  );
};
