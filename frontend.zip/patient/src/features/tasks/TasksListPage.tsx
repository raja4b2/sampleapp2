import { Link } from 'react-router-dom';
import { useGetAllTasksQuery } from '../../services/autoPilotApiTasksSlice';
import { TaskCard } from './TaskCard';

export const TasksListPage = () => {
  const { data: tasksByCategory } = useGetAllTasksQuery();
  return (
    <div className='mx-auto max-w-3xl px-4'>
      {tasksByCategory &&
        Object.entries(tasksByCategory).map(([category, tasks]) => (
          <div key={category}>
            {/* Task category */}
            <div className='py-3 text-sm font-medium text-theme-base text-opacity-90'>
              <h3 className='text-lg'>{category}</h3>
            </div>
            {/* Task List */}
            {tasks.map((task) => (
              <Link key={task.id} className='block' to={`/tasks/${task.id}`}>
                <TaskCard task={task} />
              </Link>
            ))}
          </div>
        ))}
    </div>
  );
};
