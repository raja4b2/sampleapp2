/* eslint-disable react/iframe-missing-sandbox */
// ^ TODO: see if the Acquity iframe embed can work in sandbox mode
import { ScheduleTaskPayload } from '../taskModel';
import { useSelector } from 'react-redux';
import { RootState } from '../../../store';

interface ScheduleTaskProps {
  data: ScheduleTaskPayload;
}

export const ScheduleTask = ({ data }: ScheduleTaskProps) => {
  const acquityAccountId = useSelector(
    (state: RootState) => state.environment.acquityAccountId,
  );

  const acquityUrl = new URL('https://app.acuityscheduling.com/schedule.php');
  const acquityQueryParams = {
    owner: acquityAccountId,
    calendarId: data.calendarId,
    appointmentType: data.appointmentTypeId,
    quantity: 1,
    // TODO: read these properties from the current user once auth is done
    firstName: 'Jon',
    lastName: 'Aldinger',
    email: 'jon.aldinger@proofpilot.com',
    phone: '215-555-1212',
  };

  Object.entries(acquityQueryParams).forEach(([key, value]) => {
    acquityUrl.searchParams.append(key, String(value));
  });

  return (
    <iframe
      src={acquityUrl.href}
      width='100%'
      height='2000'
      title='Schedule Appointment'
    />
  );
};
