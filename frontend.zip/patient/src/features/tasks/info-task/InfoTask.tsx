import { ButtonPrimary } from 'core/components/ButtonPrimary';
import { useNavigate } from 'react-router-dom';
import infoTaskMediaPlaceholder from '../../../assets/infoTaskMediaPlaceholder.png';
import { useSubmitInfoTaskMutation } from '../../../services/autoPilotApiTasksSlice';
import { InfoTaskPayload } from '../taskModel';
import './InfoTask.css';
interface InfoTaskProps {
  taskId: number;
  data: InfoTaskPayload;
}

export const InfoTask = ({ data, taskId }: InfoTaskProps) => {
  const [submitInfoTask] = useSubmitInfoTaskMutation();
  const navigate = useNavigate();

  return (
    <div className='w-full justify-center'>
      <div className='p-6 w-96 border rounded-lg shadow-lg mx-auto'>
        <div className='space-y-6'>
          <div className='aspect-w-10 aspect-h-7 group block w-full overflow-hidden rounded-lg'>
            <img src={data.mediaUrl || infoTaskMediaPlaceholder} alt='' />
          </div>
          <div className='flex space-x-3 items-center'>
            <div className='flex-shrink-0 flex items-center'>
              <img
                className='h-10 w-10 rounded-full'
                src={data.studyLogo}
                alt=''
              />
            </div>
            <div className='min-w-0 flex-1 text-lg font-medium'>
              {data.name}
            </div>
          </div>
          <div className='border-t border-gray-200 p-0'>
            <dl>
              <div className='py-3'>
                <dt className='text-sm font-medium text-gray-500'>
                  Study Name
                </dt>
                <dd className='mt-1 text-sm'>{data.studyName}</dd>
              </div>
              <div className='py-3'>
                <dt className='text-sm font-medium text-gray-500'>
                  Description
                </dt>
                <dd
                  className='mt-1 text-sm InfoTask'
                  dangerouslySetInnerHTML={{
                    __html: data.content,
                  }}
                />
              </div>
            </dl>
          </div>
          <div className='flex gap-x-3'>
            <ButtonPrimary
              label='Ok, got it!'
              onClick={() =>
                submitInfoTask({
                  status: 'completed',
                  taskId,
                })
                  .unwrap()
                  .then(() => {
                    navigate('/tasks');
                  })
                  .catch(() => {
                    // TODO: handle error
                  })
              }
            />
          </div>
        </div>
      </div>
    </div>
  );
};
