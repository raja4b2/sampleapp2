export interface InfoTaskPayload {
  name: string;
  studyName: string;
  content: string;
  mediaUrl: string;
  studyLogo: string;
}

export interface InfoTaskSubmission {
  status: 'completed' | 'skipped';
  taskId: number;
}

export interface ScheduleTaskPayload {
  calendarId: string;
  appointmentTypeId: string;
}

interface SurveyTaskProgress {
  isLastInput: boolean;
  totalInputs: number;
  currentInputNumber: number;
  percentComplete: number;
}

interface SurveyTaskOption {
  label: string;
  description: string;
  value: string;
}

interface SurveyTaskValidation {
  isRequired?: boolean;
}

interface SurveyTaskMetadata {
  defaultValue?: string;
  options: SurveyTaskOption[];
  validation?: SurveyTaskValidation;
}

export interface SurveyTaskPayload {
  id: string;
  label: string;
  description?: string;
  tooltip?: string;
  type: 'radio';
  progress: SurveyTaskProgress;
  metadata: SurveyTaskMetadata;
}

export interface Task {
  id: number;
  name: string;
  type: 'survey' | 'info' | 'schedule';
  status: 'pending' | 'active' | 'skipped' | 'completed';
  description?: string;
  dateAssigned: string;
  dateDue: string;
  imageUrl: string;
  category: string;
  payload: InfoTaskPayload | ScheduleTaskPayload | SurveyTaskPayload;
}

export interface TaskResponse {
  assignment: Task;
}

export interface TaskInfo extends Task {
  payload: InfoTaskPayload;
}

export interface TasksByCategory {
  [category: string]: Task[];
}

export interface TasksResponse {
  assignments: Task[];
}
