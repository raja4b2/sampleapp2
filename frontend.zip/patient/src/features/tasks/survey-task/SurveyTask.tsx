import { useState } from 'react';
import { RadioButtonGroup } from 'core/components/RadioButtonGroup';
import { ButtonPrimary } from 'core/components/ButtonPrimary';
import { SurveyTaskPayload } from '../taskModel';

interface SurveyTaskProps {
  data: SurveyTaskPayload;
}

export const SurveyTask = ({ data }: SurveyTaskProps) => {
  const [value, setValue] = useState<string | number>();

  return (
    <div className='container mx-auto mt-16 px-4 max-w-2xl'>
      <RadioButtonGroup
        label={data.label}
        onChange={setValue}
        options={data.metadata.options}
        value={value}
      />

      <ButtonPrimary
        className='mt-12 w-full'
        icon='chevronRight'
        iconPosition='right'
        isDisabled={!value}
        label='Next'
        size='lg'
      />
    </div>
  );
};
