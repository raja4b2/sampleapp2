import {
  InfoTaskSubmission,
  Task,
  TaskResponse,
  TasksResponse,
  TasksByCategory,
} from '../features/tasks/taskModel';
import { autoPilotApiBaseSlice } from './autoPilotApiBaseSlice';

const autoPilotApiTasksSlice = autoPilotApiBaseSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAllTasks: builder.query<TasksByCategory, void | never>({
      query: () => '/1/onemorebsmith/tasks',
      providesTags: ['Task'],
      transformResponse: (tasksResponse: TasksResponse): TasksByCategory => {
        // TODO: If we want to add groups back in at the API level, uncomment below.
        //       Otherwise, remove the concept of groups.
        // return groupBy(tasksResponse.assignments, (task) => task.category);
        return {
          // TODO: Move this sort logic to the backend API
          'Upcoming tasks': tasksResponse.assignments.sort((a, b) =>
            a.dateDue.localeCompare(b.dateDue),
          ),
        };
      },
    }),
    getTask: builder.query<Task, string>({
      query: (taskId) => `/1/onemorebsmith/tasks/${taskId}`,
      transformResponse: (tasksResponse: TaskResponse): Task => {
        return tasksResponse.assignment;
      },
    }),
    // TODO: determine API response format (to put in place of <Record> here)
    submitInfoTask: builder.mutation<
      Record<string, string>,
      InfoTaskSubmission
    >({
      query(body) {
        return {
          url: `/1/onemorebsmith/tasks/submit/info`,
          method: 'POST',
          body,
        };
      },
      invalidatesTags: ['Task'],
    }),
  }),
});

export const {
  useGetAllTasksQuery,
  useGetTaskQuery,
  useSubmitInfoTaskMutation,
} = autoPilotApiTasksSlice;
