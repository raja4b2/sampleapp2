import { createSlice, PayloadAction } from '@reduxjs/toolkit';

// Must match the properties defined in public/config/environment.json
export interface EnvironmentConfig {
  acquityAccountId?: number;
  autoPilotApiUrl?: string;
  environmentName?: 'prod' | 'stage' | 'dev' | 'local';
  mockApiUrl?: string;
  releaseVersion?: string;
}

const initialState: EnvironmentConfig = {
  autoPilotApiUrl: undefined,
  environmentName: undefined,
  mockApiUrl: undefined,
  releaseVersion: undefined,
};

export const environmentSlice = createSlice({
  name: 'environment',
  initialState,
  reducers: {
    setEnvironment(_state, action: PayloadAction<EnvironmentConfig>) {
      return action.payload;
    },
  },
});

export const { setEnvironment } = environmentSlice.actions;
