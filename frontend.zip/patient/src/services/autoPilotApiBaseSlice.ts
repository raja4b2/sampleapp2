import urlJoin from 'url-join';

import {
  createApi,
  fetchBaseQuery,
  BaseQueryFn,
  FetchArgs,
  FetchBaseQueryError,
} from '@reduxjs/toolkit/query/react';
import { RootState } from '../store';

const rawBaseQuery = fetchBaseQuery({
  baseUrl: '',
  prepareHeaders: (headers) => {
    // TODO: auth will go here:
    // headers.set('key', 'value');
    return headers;
  },
});

/**
 * Set our base API path at runtime. This is needed because our environment config is
 * defined at runtime (so that our static builds can be environment-agnostic).
 * @link https://redux-toolkit.js.org/rtk-query/usage/customizing-queries#constructing-a-dynamic-base-url-using-redux-state
 */
const dynamicBaseQuery: BaseQueryFn<
  string | FetchArgs,
  unknown,
  FetchBaseQueryError
> = async (args, api, extraOptions) => {
  const state = api.getState() as RootState;
  // The url can come in as 'http://url.com' or { url: 'http://url.com' }. All we're doing here is
  // modifying the string if we receive a string, or the url property value if we receive an object.
  const urlPath = typeof args === 'string' ? args : args.url;
  const modifiedUrl = urlJoin(state.environment.autoPilotApiUrl ?? '', urlPath);
  const modifiedArgs =
    typeof args === 'string' ? modifiedUrl : { ...args, url: modifiedUrl };
  return rawBaseQuery(modifiedArgs, api, extraOptions);
};

/**
 * Create a base slice for our main API. This slice provides no actual endpoints and is only used
 * to define shared attributes including the URL and headers. Each set of endpoints extends this
 * base via `apiSlice.injectEndpoints()`. This allows for code splitting - new endpoints are
 * injected at runtime based on the dynamic imports being requested as the user loads new pages
 * across the site.
 * @link https://redux-toolkit.js.org/rtk-query/overview#create-an-api-slice
 * @link https://redux.js.org/tutorials/essentials/part-8-rtk-query-advanced#injecting-endpoints
 */
export const autoPilotApiBaseSlice = createApi({
  reducerPath: 'autoPilotApi',
  baseQuery: dynamicBaseQuery,
  endpoints: () => ({}),
  tagTypes: ['Task'],
});
