/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{ts,tsx}', './index.html', '../core/**/*.{ts,tsx}'],
  plugins: [require('@tailwindcss/forms')],
  presets: [require('../tailwind.config.js')],
};
