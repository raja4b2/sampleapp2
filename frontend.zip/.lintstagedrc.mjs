import { ESLint } from 'eslint';

/**
 * ESLint throws a warning when lint-staged asks it to lint a file that is in the lint-ignore list,
 * resulting in a non-zero exit status which prevents the commit from going through. A resolution
 * in ESLint has been tied up for literally years in silly RFC land, so lint-staged has provided
 * this code as a manual workaround on their side. When ESLint finally fixes this, we'll be able
 * to add a flag to the eslint command instead of manually filtering files.
 * @see https://github.com/okonet/lint-staged#how-can-i-ignore-files-from-eslintignore
 * @see https://github.com/eslint/rfcs/pull/90
 */
const removeIgnoredFiles = async (files) => {
  const eslint = new ESLint();
  const isIgnored = await Promise.all(
    files.map((file) => {
      return eslint.isPathIgnored(file);
    })
  );
  const filteredFiles = files.filter((_, i) => !isIgnored[i]);
  return filteredFiles.join(' ');
};

export default {
  // Prettier and ESLint must be run serially against JS files to avoid race conditions (because
  // they both run against the same set of files).
  // https://github.com/okonet/lint-staged#task-concurrency
  '*.{js,ts,tsx}': [
    'prettier --write',
    async (files) => {
      const filesToLint = await removeIgnoredFiles(files);
      return [`eslint --fix --max-warnings=0 ${filesToLint}`];
    },
  ],
  // Other files have no overlap with JS or any other tasks so can be run concurrently.
  '*.{html,css,md,json,yaml,yml}': 'prettier --write',
};
