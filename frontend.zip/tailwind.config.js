/** @type {import('tailwindcss').Config} */

function addOpacity(cssVariableName, fixedOpacity) {
  return ({ opacityValue }) => {
    const cssVar = `var(${cssVariableName})`;
    if (opacityValue !== undefined) {
      const opacity = fixedOpacity ? fixedOpacity : opacityValue;
      return `rgba(${cssVar}, ${opacity})`;
    }
    return `rgb(${cssVar})`;
  };
}

function getCommonColorVariables(colorKey) {
  return {
    base: addOpacity(`--color-${colorKey}-base`),
    muted: addOpacity(`--color-${colorKey}-muted`),
    inverted: addOpacity(`--color-${colorKey}-inverted`),
    accent: addOpacity(`--color-${colorKey}-accent`),
    primary: addOpacity(`--color-${colorKey}-primary`),
    secondary: addOpacity(`--color-${colorKey}-secondary`),
    info: addOpacity(`--color-${colorKey}-info`),
    success: addOpacity(`--color-${colorKey}-success`),
    warning: addOpacity(`--color-${colorKey}-warning`),
    error: addOpacity(`--color-${colorKey}-error`),
  };
}

const abstractThemeColors = {
  backgroundColor: {
    ...getCommonColorVariables('bg'),
  },
  textColor: {
    ...getCommonColorVariables('text'),
  },
  borderColor: {
    ...getCommonColorVariables('border'),
  },
  ringColor: {
    ...getCommonColorVariables('ring'),
  },
};

module.exports = {
  content: ['./src/**/*.{ts,tsx}', './index.html', '../core/**/*.{ts,tsx}'],
  theme: {
    fontFamily: {
      sans: [
        '"Rubik"',
        '"Helvetica Neue"',
        'Arial',
        'sans-serif',
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
        '"Noto Color Emoji"',
      ],
      heading: [
        'Rubik',
        '"Helvetica Neue"',
        'Arial',
        'sans-serif',
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
        '"Noto Color Emoji"',
      ],
      mono: [
        'ui-monospace',
        'SFMono-Regular',
        'Menlo',
        'Monaco',
        'Consolas',
        '"Liberation Mono"',
        '"Courier New"',
        'monospace',
      ],
    },
    fontWeight: {
      400: 400,
      500: 500,
      700: 700,
    },
    zIndex: {
      auto: 'auto',
      inherit: 'inherit',
      initial: 'initial',
      unset: 'unset',
      local0: 0,
      local1: 1,
      local2: 2,
      local3: 3,
      menu: '5000',
      tooltip: '6000',
      rightbar: '7000',
      dialog: '8000',
      toast: '9000',
    },
    extend: {
      textColor: {
        theme: {
          ...abstractThemeColors.textColor,
          // place your custom colors here
        },
      },
      backgroundColor: {
        theme: {
          ...abstractThemeColors.backgroundColor,
        },
      },
      ringColor: {
        theme: {
          ...abstractThemeColors.ringColor,
        },
      },
      borderColor: {
        theme: {
          ...abstractThemeColors.borderColor,
        },
      },
    },
  },
};
