export const roundToDecimalPlaces = (value: number, decimalPlaces = 0) => {
  const multiplier = decimalPlaces ** 10;
  return Math.round(value * multiplier) / multiplier;
};
