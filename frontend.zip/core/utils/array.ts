export function groupBy<T>(arr: T[], fn: (item: T) => unknown) {
  return arr.reduce<Record<string, T[]>>((prev, curr) => {
    const groupKey = fn(curr) as string;
    let group = prev[groupKey];
    if (!prev.hasOwnProperty(groupKey)) {
      group = [];
    }
    group.push(curr);
    return { ...prev, [groupKey]: group };
  }, {});
}
