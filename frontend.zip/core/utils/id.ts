import { nanoid } from 'nanoid/non-secure';

/**
 * @description Generate a unique ID with optional prefix. Short IDs are fine for most cases, but
 *   if guaranteed universal uniqueness is needed (such as for database IDs), use a UUID instead.
 */
export const shortId = (prefix?: string) =>
  prefix ? `${prefix}-${nanoid()}` : nanoid();
