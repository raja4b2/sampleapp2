import clsx from 'clsx';

type StatusTypes = 'info' | 'success' | 'warning' | 'error';

interface StatusLabelProps {
  className?: string;
  label: string;
  type: StatusTypes;
}

export const StatusLabel = ({
  className,
  label,
  type,
  ...props
}: StatusLabelProps) => {
  return (
    <div
      {...props}
      className={clsx(
        className,
        'whitespace-nowrap inline-block px-4 py-1 leading-13 text-center rounded-lg border-2 text-sm',
        {
          'bg-blue-100 border-blue-500 text-blue-500': type === 'info',
          'bg-green-100 border-green-500 text-green-500': type === 'success',
          'bg-amber-100 border-amber-500 text-amber-500': type === 'warning',
          'bg-red-100 border-red-500 text-red-500': type === 'error',
        }
      )}
    >
      {label}
    </div>
  );
};
