import { ChangeEvent, ReactNode, useRef } from 'react';
import { Icon } from './Icon';
import { shortId } from '../utils/id';
import clsx from 'clsx';

interface TextInputProps {
  className?: string;
  containerProps?: React.HTMLAttributes<HTMLDivElement>;
  description?: string;
  errorMessage?: string;
  label?: ReactNode;
  onChange?(value: string): void;
  type?: 'email' | 'number' | 'password' | 'text';
  value?: string | number;
}

export const TextInput = ({
  className,
  containerProps,
  description,
  errorMessage,
  label,
  onChange,
  value,
  type = 'text',
  ...props
}: TextInputProps) => {
  const inputElementId = useRef(shortId());
  const errorElementId = useRef(shortId());
  const descriptionElementId = useRef(shortId());

  return (
    <div {...containerProps}>
      {label && (
        <label
          htmlFor={inputElementId.current}
          className='block text-sm font-medium text-theme-base'
        >
          {label}
        </label>
      )}

      <div className='relative mt-1 rounded shadow-sm'>
        <input
          {...props}
          className={clsx(
            className,
            'block w-full rounded sm:text-sm bg-theme-base text-theme-base',
            {
              'border-theme-muted focus:border-theme-base focus:ring-opacity-60 focus:ring-theme-base':
                !errorMessage,
              'border-theme-error pr-10 text-theme-error placeholder:text-theme-error focus:border-theme-error focus:outline-none focus:ring-theme-error':
                errorMessage,
            }
          )}
          id={inputElementId.current}
          onChange={(event: ChangeEvent<HTMLInputElement>) =>
            onChange?.(event.target.value)
          }
          type={type}
          value={value ?? ''}
          aria-invalid={errorMessage ? 'true' : undefined}
          aria-describedby={
            errorMessage ? errorElementId.current : descriptionElementId.current
          }
        />
        {errorMessage && (
          <div className='pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3'>
            <Icon type='exclamationCircle' color='error' />
          </div>
        )}
      </div>

      {description && (
        <p
          className='mt-1 text-sm text-theme-base'
          id={descriptionElementId.current}
        >
          {description}
        </p>
      )}

      {errorMessage && (
        <p
          className='mt-1 text-sm text-theme-error'
          id={errorElementId.current}
        >
          {errorMessage}
        </p>
      )}
    </div>
  );
};
