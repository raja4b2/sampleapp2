import { ChangeEvent, ReactNode, useRef } from 'react';
import { shortId } from '../utils/id';

interface SelectOptions {
  label: string;
  value: string | number;
}

interface SelectProps {
  description?: string;
  errorMessage?: string;
  label?: ReactNode;
  onChange?(value: string): void;
  options: SelectOptions[];
  value?: string | number;
}

export const Select = ({
  description,
  errorMessage,
  label,
  onChange,
  options,
  value,
  ...props
}: SelectProps) => {
  const selectElementId = useRef(shortId());

  return (
    <div>
      {label && (
        <label
          htmlFor={selectElementId.current}
          className='block text-sm font-medium text-theme-base'
        >
          {label}
        </label>
      )}
      <select
        {...props}
        className='mt-1 block w-full rounded bg-theme-base text-theme-base border-theme-muted py-2 pl-3 pr-10 focus:border-theme-base focus:outline-none focus:ring-theme-base focus:ring-opacity-60 sm:text-sm'
        id={selectElementId.current}
        onChange={(event: ChangeEvent<HTMLSelectElement>) =>
          onChange?.(event.target.value)
        }
        value={value}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};
