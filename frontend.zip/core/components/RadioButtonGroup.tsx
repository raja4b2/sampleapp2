import { ReactNode } from 'react';
import { RadioGroup } from '@headlessui/react';
import clsx from 'clsx';

interface Options {
  label: string;
  value: string | number;
  description?: string;
}

interface RadioButtonGroupProps {
  label?: ReactNode;
  options: Options[];
  onChange?(value: string | number): void;
  value?: string | number;
}

export const RadioButtonGroup = ({
  label,
  onChange,
  options,
  value,
}: RadioButtonGroupProps) => {
  return (
    <RadioGroup value={value ?? null} onChange={onChange}>
      {label && (
        <RadioGroup.Label className='block mb-4'>{label}</RadioGroup.Label>
      )}
      <div className='space-y-3'>
        {options.map((option) => (
          <RadioGroup.Option
            key={option.label}
            value={option.value}
            // option container
            className={({ checked }) =>
              clsx(
                'relative p-4 flex cursor-pointer border rounded-lg focus:outline-none',
                {
                  'z-10 border-blue-200 bg-blue-50': checked,
                  'bg-white border-gray-200': !checked,
                }
              )
            }
          >
            {({ active, checked }) => (
              <>
                {/* radio control outer */}
                <span
                  className={clsx(
                    'mt-0.5 h-5 w-5 shrink-0 cursor-pointer rounded-full border flex items-center justify-center',
                    {
                      'bg-blue-600 border-transparent': checked,
                      'bg-white border-gray-300': !checked,
                      'ring-1 ring-offset-2 ring-blue-600': active,
                    }
                  )}
                  aria-hidden='true'
                >
                  {/* radio control inner */}
                  <span className='rounded-full bg-white w-2 h-2' />
                </span>
                {/* text container */}
                <span className='ml-4 flex flex-col'>
                  {/* label */}
                  <RadioGroup.Label
                    as='span'
                    className={clsx('block text-md', {
                      'text-blue-900': checked,
                      'text-gray-900': !checked,
                    })}
                  >
                    {option.label}
                  </RadioGroup.Label>
                  {/* description */}
                  {option.description && (
                    <RadioGroup.Description
                      as='span'
                      className={clsx('block text-sm', {
                        'text-blue-700': checked,
                        'text-gray-500': !checked,
                      })}
                    >
                      {option.description}
                    </RadioGroup.Description>
                  )}
                </span>
              </>
            )}
          </RadioGroup.Option>
        ))}
      </div>
    </RadioGroup>
  );
};
