import clsx from 'clsx';
import {
  ExclamationCircleIcon as ExclamationCircleIconSmall,
  ChevronDownIcon,
  ChevronRightIcon,
  CalendarIcon,
  ChevronLeftIcon,
  DocumentTextIcon,
} from '@heroicons/react/20/solid';
import {
  ArrowSmallRightIcon,
  ClockIcon,
  ExclamationCircleIcon,
  ListBulletIcon,
  PlayPauseIcon,
} from '@heroicons/react/24/outline';

const Icons = {
  arrowRight: ArrowSmallRightIcon,
  chevronDown: ChevronDownIcon,
  chevronRight: ChevronRightIcon,
  clock: ClockIcon,
  exclamationCircle: ExclamationCircleIcon,
  exclamationCircleSmall: ExclamationCircleIconSmall,
  listBullet: ListBulletIcon,
  playPause: PlayPauseIcon,
  calendar: CalendarIcon,
  chevronLeft: ChevronLeftIcon,
  documentText: DocumentTextIcon,
};

export type IconTypes = keyof typeof Icons;

const IconColors = {
  white: 'text-white',
  gray: 'text-theme-base',
  error: 'text-theme-error',
};

interface IconProps {
  className?: string;
  color?: keyof typeof IconColors;
  isDecorative?: boolean;
  size?: 'sm' | 'md' | 'lg';
  type: IconTypes;
}

export const Icon = ({
  className,
  color = 'gray',
  isDecorative = true,
  size = 'md',
  type,
  ...props
}: IconProps) => {
  const IconComponent = Icons[type];
  return (
    <IconComponent
      {...props}
      aria-hidden={isDecorative ? 'true' : undefined}
      className={clsx(className, IconColors[color], {
        'h-5 w-5': size === 'sm',
        'h-6 w-6': size === 'md',
        'h-8 w-8 stroke-2': size === 'lg',
      })}
    />
  );
};
