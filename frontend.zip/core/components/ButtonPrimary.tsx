import { ReactNode } from 'react';
import { Icon, IconTypes } from './Icon';
import clsx from 'clsx';

interface ButtonPrimaryProps {
  className?: string;
  icon?: IconTypes;
  iconPosition?: 'left' | 'right';
  isDisabled?: boolean;
  label?: ReactNode;
  onClick?(): void;
  size?: 'md' | 'lg';
  type?: 'button' | 'submit';
}

export const ButtonPrimary = ({
  className,
  label,
  icon,
  iconPosition = 'left',
  isDisabled = false,
  onClick,
  size = 'md',
  type = 'button',
  ...props
}: ButtonPrimaryProps) => {
  return (
    <button
      {...props}
      className={clsx(
        'bg-theme-primary text-theme-inverted inline-flex rounded border justify-center items-center border-transparent font-500 shadow-sm',
        {
          'px-4 py-2 text-sm': size === 'md',
          'px-8 py-3 text-md': size === 'lg',
          'bg-opacity-90  hover:bg-opacity-100 focus:outline-none focus:ring-2 focus:ring-theme-primary focus:ring-offset-2':
            !isDisabled,
          'bg-opacity-60 cursor-not-allowed': isDisabled,
        },
        className
      )}
      disabled={isDisabled}
      onClick={onClick}
      type={type}
    >
      {icon && iconPosition === 'left' && (
        <Icon
          className={clsx({
            'mr-1 -ml-0.5': Boolean(label),
          })}
          color='white'
          size='sm'
          type={icon}
        />
      )}
      {label}
      {icon && iconPosition === 'right' && (
        <Icon
          className={clsx({
            'ml-1 -mr-0.5': Boolean(label),
          })}
          color='white'
          size='sm'
          type={icon}
        />
      )}
    </button>
  );
};
