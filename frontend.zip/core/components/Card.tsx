/*
 * This component would give outer container for the card
 */

import clsx from 'clsx';
import { ReactNode } from 'react';

type CardTypes = 'base' | 'info' | 'success' | 'warning' | 'error';

interface CardProps {
  className?: string;
  type?: CardTypes;
  onClick?(): void;
  isHoverable?: boolean;
  children: ReactNode;
}

export const Card = ({
  className,
  type = 'base',
  children,
  isHoverable = false,
  onClick,
  ...props
}: CardProps) => {
  const hasHoverState = Boolean(onClick) || isHoverable;

  return (
    <div
      onClick={onClick}
      onKeyUp={(event: React.KeyboardEvent<HTMLDivElement>) => {
        event.key === 'Enter' && onClick?.();
      }}
      {...props}
      className={clsx(
        className,
        'border mt-3 first:mt-0 last:mb-4 px-4 py-2 sm:px-6 rounded-2xl shadow drop-shadow-lg',
        {
          'cursor-pointer hover:saturate-150': hasHoverState,
          'bg-theme-base border-theme-muted text-theme-base': type === 'base',
          'hover:bg-gray-100': type === 'base' && hasHoverState, // TO-DO: Optimize this
          'bg-theme-info border-theme-info text-theme-inverted':
            type === 'info',
          'bg-theme-success border-theme-success text-theme-inverted':
            type === 'success',
          'bg-theme-warning border-theme-warning text-theme-inverted':
            type === 'warning',
          'bg-theme-error border-theme-error text-theme-inverted':
            type === 'error',
        },
      )}
    >
      {children}
    </div>
  );
};
