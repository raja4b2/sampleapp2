/* 
Temp created dropdown component for demo purpose, 
TO_DO: Improve the component to make it usable as generic component
*/

import { Fragment } from 'react';
import { Menu, Transition } from '@headlessui/react';
import clsx from 'clsx';
import { Icon } from './Icon';

interface optionProps {
  id: number;
  text: string;
}
interface DropdownProps {
  label?: string;
  options?: optionProps[];
  onChange?(option: optionProps): void;
  variant: 'primary' | 'secondary'; // eventually we want to use variant
}

export const Dropdown = ({ label, options, onChange }: DropdownProps) => {
  return (
    <Menu as='div' className='relative inline-block text-left'>
      <div>
        <Menu.Button className='inline-flex w-full justify-center items-center rounded bg-theme-muted px-4 py-2 text-sm font-medium text-theme-base shadow-sm hover:opacity-100 focus:outline-none focus:ring-1 focus:ring-theme-muted focus:ring-offset-1 focus:opacity-100'>
          {label}
          <Icon className='-mr-1 ml-2 h-5 w-5' type='chevronDown' />
        </Menu.Button>
      </div>

      <Transition
        as={Fragment}
        enter='transition ease-out duration-100'
        enterFrom='transform opacity-0 scale-95'
        enterTo='transform opacity-100 scale-100'
        leave='transition ease-in duration-75'
        leaveFrom='transform opacity-100 scale-100'
        leaveTo='transform opacity-0 scale-95'
      >
        <Menu.Items className='absolute z-10 mt-2 w-28 origin-top-right rounded bg-theme-base shadow-lg ring-1 ring-theme-muted ring-opacity-5 focus:outline-none'>
          <div className='py-1'>
            {options?.map((option) => {
              return (
                <Menu.Item key={option.id}>
                  {({ active }) => (
                    <button
                      className={clsx(
                        'block px-4 py-2 text-sm cursor-pointer',
                        {
                          'text-theme-primary': active,
                          'text-theme-base': !active,
                        }
                      )}
                      onClick={() => {
                        onChange?.(option);
                      }}
                    >
                      {option.text}
                    </button>
                  )}
                </Menu.Item>
              );
            })}
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
};
