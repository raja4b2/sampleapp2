import { ReactNode } from 'react';
import { Icon, IconTypes } from './Icon';
import clsx from 'clsx';

interface ButtonSecondaryProps {
  className?: string;
  icon?: IconTypes;
  iconPosition?: 'left' | 'right';
  isDisabled?: boolean;
  label?: ReactNode;
  onClick?(): void;
  type?: 'button' | 'submit';
}

export const ButtonSecondary = ({
  className,
  label,
  icon,
  iconPosition = 'left',
  isDisabled = false,
  onClick,
  type = 'button',
  ...props
}: ButtonSecondaryProps) => {
  return (
    <button
      {...props}
      className={clsx(
        'bg-theme-secondary bg-opacity-90 text-theme-base inline-flex rounded border bg-opacity-90 items-center  border-transparent px-4 py-2 text-sm font-medium shadow-sm',
        {
          'shadow-sm hover:bg-opacity-100 focus:outline-none focus:ring-2 focus:ring-theme-secondary focus:ring-offset-2':
            !isDisabled,
          'bg-opacity-60 text-opacity-60 shadow-sm cursor-not-allowed':
            isDisabled,
        },
        className
      )}
      disabled={isDisabled}
      onClick={onClick}
      type={type}
    >
      {icon && iconPosition === 'left' && (
        <Icon
          className={clsx('text-theme-secondary', {
            'mr-1 -ml-0.5': Boolean(label),
          })}
          type={icon}
        />
      )}
      {label}
      {icon && iconPosition === 'right' && (
        <Icon
          className={clsx('text-theme-secondary', {
            'ml-1 -mr-0.5': Boolean(label),
          })}
          type={icon}
        />
      )}
    </button>
  );
};
